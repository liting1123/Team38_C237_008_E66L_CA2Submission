-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: glpfrl.h.filess.io    Database: CA2_sumtopwar
-- ------------------------------------------------------
-- Server version	8.0.36-28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `contact` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `role` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'Brandie','Brandie.lishan@gmail.com','21bd12dc183f740ee76f27b78eb39c8ad972a757','82381617','woodlands ','user'),(3,'alice','alice@alice.com','02726d40f378e716981c4321d60ba3a325ed6a4c','98765432','Woodlands Ave 2','user'),(4,'alice1','alice1@alice.com','02726d40f378e716981c4321d60ba3a325ed6a4c','98765433','Woodlands Ave 3','admin'),(5,'BrandieAdmin','brandietanlishan@gmail.com','a30dc3a21f69390fd8fa888ce3d4214bbe9b81fe','97128531','CWP','admin'),(8,'Chupapa','hellobros@gmail.com','4ab8317d7f5a46da3dfc1041c36116ecf3d16a7e','554332','ff 43 ffd','admin'),(9,'Chupapi','hellobroa@gmail.com','de9f5fd775d7305609d5e408353aa892c1edf58c','554332','ff 43 ffd','user'),(27,'alice','alice@gmail.com','02726d40f378e716981c4321d60ba3a325ed6a4c','87339618','Blk 269c Compassvale Link#16-101','user'),(29,'Chupapu','hellobroas@gmail.com','de9f5fd775d7305609d5e408353aa892c1edf58c','554332','ff 43 ffd','admin');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-30 20:11:15
