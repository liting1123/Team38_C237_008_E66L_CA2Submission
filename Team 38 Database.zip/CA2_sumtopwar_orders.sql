-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: glpfrl.h.filess.io    Database: CA2_sumtopwar
-- ------------------------------------------------------
-- Server version	8.0.36-28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `idorder` int NOT NULL AUTO_INCREMENT,
  `iduser` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`idorder`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (18,'3','alice',6.30,'2025-07-25 08:54:27',NULL),(19,'3','alice',9.80,'2025-07-25 09:00:35',NULL),(20,'3','alice',4.02,'2025-07-25 13:08:54',NULL),(21,'3','alice',7.00,'2025-07-26 05:21:30',NULL),(22,'3','alice',4.20,'2025-07-26 08:03:16',NULL),(23,'3','alice',4.20,'2025-07-26 08:03:31',NULL),(24,'3','alice',7.90,'2025-07-26 08:14:11',NULL),(25,'3','alice',7.90,'2025-07-26 08:16:14',NULL),(26,'3','alice',2.10,'2025-07-26 08:20:45',NULL),(27,'3','alice',2.10,'2025-07-26 08:20:53',NULL),(28,'3','alice',2.10,'2025-07-26 08:21:09',NULL),(29,'3','alice',2.10,'2025-07-26 08:21:42',NULL),(30,'3','alice',2.10,'2025-07-26 08:24:39',NULL),(31,'3','alice',2.10,'2025-07-26 08:27:15',NULL),(32,'3','alice',2.10,'2025-07-26 08:27:44',NULL),(33,'3','alice',2.10,'2025-07-26 08:28:28',NULL),(34,'3','alice',2.10,'2025-07-26 08:30:36',NULL),(35,'3','alice',2.10,'2025-07-26 08:34:39',NULL),(36,'3','alice',2.10,'2025-07-26 08:37:02',NULL),(37,'3','alice',2.10,'2025-07-26 08:38:41',NULL),(38,'3','alice',2.10,'2025-07-26 08:40:56','Paid'),(39,'3','alice',2.10,'2025-07-26 09:14:05','Paid'),(40,'3','alice',2.10,'2025-07-26 09:30:19',NULL),(41,'3','alice',2.10,'2025-07-26 09:34:02',NULL),(42,'3','alice',2.10,'2025-07-26 09:36:00',NULL),(43,'3','alice',2.80,'2025-07-26 09:36:41',NULL),(44,'3','alice',2.80,'2025-07-26 09:38:31','Paid'),(45,'3','alice',2.10,'2025-07-28 09:15:29',NULL),(46,'3','alice',2.80,'2025-07-28 09:15:36',NULL),(47,'3','alice',7.70,'2025-07-28 09:15:46',NULL),(48,'3','alice',4.90,'2025-07-28 09:21:13',NULL),(49,'3','alice',4.90,'2025-07-28 09:21:18',NULL),(50,'3','alice',2.10,'2025-07-28 09:21:31',NULL),(51,'3','alice',7.00,'2025-07-28 09:27:51',NULL),(52,'3','alice',7.00,'2025-07-28 09:29:14',NULL),(53,'3','alice',7.00,'2025-07-28 09:33:12',NULL),(54,'3','alice',5.60,'2025-07-28 09:47:54',NULL),(55,'3','alice',8.40,'2025-07-29 02:21:30',NULL),(56,'3','alice',2.10,'2025-07-29 02:21:40',NULL),(57,'3','alice',4.90,'2025-07-29 02:27:28',NULL),(58,'3','alice',7.00,'2025-07-29 02:34:38',NULL),(59,'3','alice',2.10,'2025-07-29 02:45:37',NULL),(60,'3','alice',2.10,'2025-07-29 06:11:19',NULL),(61,'26','abc',2.10,'2025-07-29 10:34:54','Paid'),(62,'9','Chupapi',2.10,'2025-07-29 12:06:43',NULL),(63,'3','alice',2.10,'2025-07-29 13:33:30',NULL),(64,'3','alice',5.80,'2025-07-29 15:04:21',NULL),(65,'3','alice',2.10,'2025-07-29 15:04:31',NULL),(66,'3','alice',2.10,'2025-07-29 15:06:20',NULL),(67,'3','alice',4.20,'2025-07-29 15:06:25',NULL),(68,'3','alice',2.10,'2025-07-29 15:06:50',NULL),(69,'3','alice',10.00,'2025-07-29 15:07:29',NULL),(70,'2','Brandie',6.30,'2025-07-29 16:57:15',NULL),(71,'2','Brandie',7.70,'2025-07-29 17:09:22',NULL),(72,'2','Brandie',7.70,'2025-07-29 17:09:31',NULL),(73,'2','Brandie',11.60,'2025-07-29 17:10:00',NULL),(74,'2','Brandie',4.20,'2025-07-29 17:10:12',NULL),(75,'2','Brandie',4.20,'2025-07-29 17:12:44',NULL),(76,'2','Brandie',16.50,'2025-07-29 17:18:30',NULL),(77,'2','Brandie',4.20,'2025-07-30 02:43:01',NULL),(78,'2','Brandie',4.20,'2025-07-30 03:07:42',NULL),(79,'2','Brandie',2.10,'2025-07-30 03:10:02',NULL),(80,'2','Brandie',2.10,'2025-07-30 03:10:28',NULL),(81,'3','alice',4.20,'2025-07-30 03:23:41',NULL),(82,'3','alice',8.60,'2025-07-30 03:24:21',NULL),(83,'3','alice',8.60,'2025-07-30 03:24:29',NULL),(84,'3','alice',2.10,'2025-07-30 03:27:17',NULL),(85,'3','alice',2.10,'2025-07-30 03:28:45',NULL),(86,'30','Chupape',4.20,'2025-07-30 03:29:13',NULL),(87,'30','Chupape',4.20,'2025-07-30 03:29:58',NULL),(88,'3','alice',2.10,'2025-07-30 03:30:18',NULL),(89,'3','alice',2.10,'2025-07-30 03:32:02',NULL),(90,'3','alice',2.10,'2025-07-30 03:34:25',NULL),(91,'3','alice',2.10,'2025-07-30 03:38:10',NULL),(92,'3','alice',5.80,'2025-07-30 03:44:29',NULL),(93,'3','alice',2.10,'2025-07-30 03:44:56',NULL),(94,'3','alice',2.10,'2025-07-30 03:46:04',NULL),(95,'3','alice',4.20,'2025-07-30 04:22:32',NULL),(96,'3','alice',4.20,'2025-07-30 04:27:02',NULL),(97,'2','Brandie',2.10,'2025-07-30 04:52:43',NULL),(98,'5','BrandieAdmin',2.10,'2025-07-30 05:09:51',NULL),(99,'5','BrandieAdmin',4.20,'2025-07-30 05:10:13',NULL),(100,'5','BrandieAdmin',4.20,'2025-07-30 05:10:22',NULL),(101,'5','BrandieAdmin',2.80,'2025-07-30 05:11:37',NULL),(102,'2','Brandie',2.10,'2025-07-30 05:13:09',NULL),(103,'2','Brandie',2.10,'2025-07-30 05:29:09',NULL),(104,'2','Brandie',2.10,'2025-07-30 05:32:09',NULL),(105,'2','Brandie',2.10,'2025-07-30 05:32:53',NULL),(106,'2','Brandie',2.10,'2025-07-30 05:36:31',NULL),(107,'2','Brandie',2.10,'2025-07-30 05:40:12',NULL),(108,'2','Brandie',2.10,'2025-07-30 05:40:37',NULL),(109,'2','Brandie',2.10,'2025-07-30 05:41:15',NULL),(110,'2','Brandie',2.10,'2025-07-30 05:42:10',NULL),(111,'2','Brandie',2.10,'2025-07-30 05:42:28',NULL),(112,'2','Brandie',2.10,'2025-07-30 05:43:03',NULL),(113,'2','Brandie',2.10,'2025-07-30 05:43:08',NULL),(114,'2','Brandie',2.10,'2025-07-30 05:47:43',NULL),(115,'2','Brandie',2.10,'2025-07-30 05:52:03',NULL),(116,'2','Brandie',2.10,'2025-07-30 05:53:24',NULL),(117,'2','Brandie',2.10,'2025-07-30 05:58:48',NULL),(118,'2','Brandie',2.10,'2025-07-30 05:58:59',NULL),(119,'2','Brandie',2.10,'2025-07-30 05:59:17',NULL),(120,'2','Brandie',2.10,'2025-07-30 05:59:50',NULL),(121,'2','Brandie',2.10,'2025-07-30 06:08:49',NULL),(122,'2','Brandie',4.20,'2025-07-30 06:45:55',NULL),(123,'2','Brandie',5.60,'2025-07-30 06:46:16',NULL),(124,'2','Brandie',2.10,'2025-07-30 07:02:08',NULL),(125,'2','Brandie',2.10,'2025-07-30 09:07:30',NULL),(126,'2','Brandie',2.10,'2025-07-30 09:07:39',NULL),(127,'2','Brandie',2.10,'2025-07-30 09:09:10',NULL),(128,'2','Brandie',2.10,'2025-07-30 09:09:39',NULL),(129,'7','test',14.70,'2025-07-30 10:40:44','Paid'),(130,'7','test',39.20,'2025-07-30 10:52:37',NULL),(131,'7','test',24.40,'2025-07-30 10:53:17','Paid'),(132,'7','test',2.10,'2025-07-30 10:53:38','Paid'),(133,'7','test',2.10,'2025-07-30 10:56:22','Paid'),(134,'7','test',2.10,'2025-07-30 10:57:11','Paid'),(135,'7','test',2.10,'2025-07-30 10:57:48','Paid'),(136,'2','Brandie',4.90,'2025-07-30 11:08:48',NULL),(137,'2','Brandie',4.20,'2025-07-30 11:16:32',NULL),(138,'2','Brandie',4.20,'2025-07-30 11:22:22','Paid'),(139,'2','Brandie',5.80,'2025-07-30 11:25:56','Paid'),(140,'3','alice',2.10,'2025-07-30 11:37:14',NULL),(141,'3','alice',4.20,'2025-07-30 11:37:20',NULL),(142,'2','Brandie',7.00,'2025-07-30 11:37:50',NULL),(143,'2','Brandie',14.00,'2025-07-30 11:38:13','Paid'),(144,'2','Brandie',2.10,'2025-07-30 12:06:10',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-30 20:11:21
